<section>
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div id="owl-slider1" class="owl-carousel owl-theme">
                        <?php 
                            $all_published_slider = DB::table('tbl_slider')
                                                    ->where('publication_status',1)
                                                    ->get();
                            foreach($all_published_slider as $v_slider){

                            ?>
                        <div class="slideritems">
                            
                            <img src="<?php echo e(URL::to($v_slider->slider_image)); ?>" class="img-responsive" alt="" />
                            <div class="overlaytext">
                                <h4 class="slidertext1"><?php echo e($v_slider->slider_text1); ?></h4> <br>
                                <p><?php echo e($v_slider->slider_text2); ?></p>
                            </div>
                        </div> 
                        
                       <?php } ?>   

                    </div>
                     
                </div>
            </div>
        </div>
    </section><?php /**PATH C:\xampp\htdocs\l-ec\resources\views/slider.blade.php ENDPATH**/ ?>