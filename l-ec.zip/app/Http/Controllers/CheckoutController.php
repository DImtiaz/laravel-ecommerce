<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use Session;
use Illuminate\Support\Facades\Redirect;

class CheckoutController extends Controller
{
    public function customer_login_check(){
    	return view('pages.login');
    }

    public function customer_registration(Request $request){
    	$data = array();
    	$data['customer_full_name']= $request->customer_name;
    	$data['customer_email']= $request->customer_email;
    	$data['customer_password']= md5($request->customer_password);
    	$data['customer_mobile_number']= $request->mobile_number;

    	$customer_id=DB::table('tbl_customer')
    				->insertGetId($data);

    	Session::put('customer_id', $customer_id);
    	Session::put('customer_name', $request->customer_name);
    	return Redirect('/checkout'); 
    }

    public function checkout(){
    	return view('pages.checkout');
    }
}
